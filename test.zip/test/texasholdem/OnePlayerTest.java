/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package texasholdem;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author adams_000
 */
public class OnePlayerTest {
    
    public OnePlayerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of updatePot method, of class OnePlayer.
     */
    @Test
    public void testUpdatePot() {
        
        System.out.println("updatePot");
        int x = 5;
        OnePlayer instance = new OnePlayer();
        int y = instance.updatePot(x);
        assertEquals(5,y);
        // TODO review the generated test code and remove the default call to fail.
        fail("UpdatePot didnt update correctly");
    }

   

    /**
     * Test of resetPot method, of class OnePlayer.
     */
    @Test
    public void testResetPot() {
        System.out.println("resetPot");
        OnePlayer instance = new OnePlayer();
        instance.resetPot();
        assertEquals(0,instance.getPot());
        // TODO review the generated test code and remove the default call to fail.
        fail("Pot not 0 after reset");
    }

    /**
     * Test of updateChips method, of class OnePlayer.
     */
    @Test
    public void testUpdateChips() {
        System.out.println("updateChips");
        OnePlayer instance = new OnePlayer();
        
        instance.p1.getChips();
        String s = "Chips:" + instance.p1.getChips();
        instance.updateChips();
        assertTrue(s.equals("Chips:" + instance.p1.getChips()) );
        // TODO review the generated test code and remove the default call to fail.
        fail("One players p1 chip label did not display the correct String");
    }

    /**
     * Test of getWinner method, of class OnePlayer.
     */
    @Test
    public void testGetWinner() {
        System.out.println("getWinner");
        OnePlayer instance = new OnePlayer();
        
        instance.p1.setHandValue(5);
        instance.AI1.setHandValue(6);
        instance.AI2.setHandValue(7);
        instance.AI1.didFold = 1;
        instance.AI2.didLose = 1;
        instance.AI3.setHandValue(2);
        instance.setPot(5);
        instance.p1.setChips(0);
        
        
       
        instance.getWinner();
        assertEquals(5,instance.p1.getChips());
        // TODO review the generated test code and remove the default call to fail.
        fail("winners chips did not update correctly");
    }
     @Test
    public void testGetWinnerdidFold() {
        System.out.println("getWinner");
        OnePlayer instance = new OnePlayer();
        
        instance.p1.setHandValue(5);
        instance.AI1.setHandValue(6);
        instance.AI2.setHandValue(7);
        instance.AI1.didFold = 1;
        instance.AI2.didLose = 1;
        instance.AI3.setHandValue(2);
        instance.setPot(5);
        instance.p1.setChips(0);
        instance.AI3.setChips(0);
        
        
       
        instance.getWinner();
        assertFalse(instance.AI3.getChips() == 5 );
        // TODO review the generated test code and remove the default call to fail.
        fail("didLose didnt cause AI2 handValue to become 0");
    }
    public void testGetWinnerdidLose() {
        System.out.println("getWinner");
        OnePlayer instance = new OnePlayer();
        
        instance.p1.setHandValue(5);
        instance.AI1.setHandValue(6);
        instance.AI2.setHandValue(7);
        instance.AI1.didFold = 1;
        instance.AI2.didLose = 1;
        instance.AI3.setHandValue(2);
        instance.setPot(5);
        instance.p1.setChips(0);
        instance.AI2.setChips(0);
        
        
       
        instance.getWinner();
        assertFalse(instance.AI2.getChips() == 5 );
        // TODO review the generated test code and remove the default call to fail.
        fail("didLose didnt cause AI2 handValue to become 0");
    }

    /**
     * Test of deal method, of class OnePlayer.
     */
    @Test
    public void testDealPlayerHand() {
        System.out.println("deal");
        OnePlayer instance = new OnePlayer();
       
        instance.deal();
        
        assertSame(instance.p1.hand.get(0), instance.d.deck.get(0));
        assertSame(instance.p1.hand.get(1), instance.d.deck.get(1));
        assertSame(instance.AI1.hand.get(2), instance.d.deck.get(2));
        assertSame(instance.AI1.hand.get(3), instance.d.deck.get(3));
        assertSame(instance.AI2.hand.get(4), instance.d.deck.get(4));
        assertSame(instance.AI2.hand.get(5), instance.d.deck.get(5));
        assertSame(instance.AI3.hand.get(6), instance.d.deck.get(6));
        assertSame(instance.AI3.hand.get(7), instance.d.deck.get(7));
        
        // TODO review the generated test code and remove the default call to fail.
        fail("Player hands do not have the proper cards");
    }
     @Test
    public void testDealCommunityCards() {
        System.out.println("deal");
        OnePlayer instance = new OnePlayer();
       
        instance.deal();
        
        assertSame(instance.cc1, instance.d.deck.get(8));
        assertSame(instance.cc2, instance.d.deck.get(9));
        assertSame(instance.cc3, instance.d.deck.get(10));
        assertSame(instance.cc4, instance.d.deck.get(11));
        assertSame(instance.cc5, instance.d.deck.get(12));
           // TODO review the generated test code and remove the default call to fail.
        fail("Community Cards contain wrong card");
    }

    
    
    /**
     * Test of checkNegative method, of class OnePlayer.
     */
    @Test
    public void testCheckNegative() {
        System.out.println("checkNegative");
        Player p = new Player();
        OnePlayer instance = new OnePlayer();
        p.setChips(-1);
        instance.checkNegative(p);
        assertFalse(p.getChips()<0);
        // TODO review the generated test code and remove the default call to fail.
        fail("Chips went into negative");
    }

    /**
     * Test of reset method, of class OnePlayer.
     */
    @Test
    public void testReset() {
        System.out.println("reset");
        OnePlayer instance = new OnePlayer();
        instance.reset();
        assertEquals(0,instance.p1.getTotalBet());
        assertEquals(0,instance.AI1.getTotalBet());
        assertEquals(0,instance.AI2.getTotalBet());
        assertEquals(0,instance.AI3.getTotalBet());
        
        // TODO review the generated test code and remove the default call to fail.
        fail("Total bets were not reset");
    }

}

   